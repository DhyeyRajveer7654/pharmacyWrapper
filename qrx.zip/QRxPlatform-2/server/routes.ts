import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// API endpoints for the contact form submission
export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint for contact form
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, service, message } = req.body;
      
      // Validate input
      if (!name || !email || !service || !message) {
        return res.status(400).json({ message: 'All fields are required' });
      }
      
      // In a real application, you would store the contact form submission
      // or send an email. Here we'll just return a success response.
      
      // For demonstration purposes only - no actual email is sent
      res.status(200).json({ 
        success: true, 
        message: 'Your message has been received. We will get back to you soon.' 
      });
    } catch (error) {
      console.error('Contact form submission error:', error);
      res.status(500).json({ message: 'An error occurred while processing your request.' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
