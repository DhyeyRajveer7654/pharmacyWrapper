import { Toaster } from "@/components/ui/toaster";
import { Route, Switch } from "wouter";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import RegulatoryCompliance from "./pages/RegulatoryCompliance";
import QualityAssurance from "./pages/QualityAssurance";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/regulatory-compliance" component={RegulatoryCompliance} />
          <Route path="/quality-assurance" component={QualityAssurance} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Toaster />
    </div>
  );
}

export default App;
