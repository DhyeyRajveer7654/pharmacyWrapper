import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section id="home" className="pt-24 pb-12 md:pt-32 md:pb-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="font-bold text-3xl md:text-4xl lg:text-5xl text-neutral-800 leading-tight mb-4">
              Professional Solutions for <span className="text-primary">Medical</span> & <span className="text-primary">Pharmaceutical</span> Industries
            </h1>
            <p className="text-neutral-700 text-lg mb-6">
              Ensuring compliance and quality in healthcare through expert consulting and innovative solutions.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Link href="#services">
                <Button size="lg" className="w-full sm:w-auto text-base">
                  Our Services
                </Button>
              </Link>
              <Link href="#contact">
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-base">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
              alt="Medical professional in laboratory" 
              className="rounded-lg shadow-lg w-full h-auto"
              width="600"
              height="400"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
