import SectionTitle from "@/components/ui/section-title";
import ServiceCard from "@/components/ui/service-card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ClipboardCheck, CheckCircle } from "lucide-react";

const ServicesSection = () => {
  return (
    <section id="services" className="py-12 md:py-20 bg-neutral-100">
      <div className="container mx-auto px-4">
        <SectionTitle 
          title="Our Services" 
          subtitle="We offer comprehensive solutions tailored to the unique needs of medical and pharmaceutical organizations."
          centered
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <ServiceCard 
            title="Regulatory Compliance"
            description="Navigate complex regulatory landscapes with our expert guidance. We ensure your processes and products meet all necessary standards and requirements."
            icon={ClipboardCheck}
            features={[
              "FDA and EMA compliance consulting",
              "Regulatory documentation preparation",
              "Compliance training programs"
            ]}
            linkTo="/regulatory-compliance"
            bgColor="bg-primary"
          />
          
          <ServiceCard 
            title="Quality Assurance"
            description="Maintain the highest standards in your processes and products with our comprehensive quality assurance services and solutions."
            icon={CheckCircle}
            features={[
              "GMP/GLP/GCP compliance",
              "Quality management system implementation",
              "Audit preparation and management"
            ]}
            linkTo="/quality-assurance"
            bgColor="bg-secondary"
            buttonColor="secondary"
          />
        </div>
        
        <div className="mt-12 text-center">
          <Link href="#contact">
            <Button variant="outline" size="lg">
              Request Custom Services
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
