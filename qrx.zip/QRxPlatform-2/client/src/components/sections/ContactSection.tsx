import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import SectionTitle from "@/components/ui/section-title";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Facebook, Linkedin, Mail, MapPin, Phone, Twitter, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  service: z.string().min(1, { message: "Please select a service" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
});

type FormValues = z.infer<typeof formSchema>;

const ContactSection = () => {
  const { toast } = useToast();
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      service: "",
      message: "",
    },
  });

  function onSubmit(data: FormValues) {
    toast({
      title: "Message Sent",
      description: "Thank you for your message! We will get back to you soon.",
    });
    form.reset();
  }

  return (
    <section id="contact" className="py-12 md:py-20 bg-neutral-100">
      <div className="container mx-auto px-4">
        <SectionTitle 
          title="Contact Us" 
          subtitle="Reach out to our team for personalized consulting services or to learn more about how we can support your organization."
          centered
        />
        
        <div className="flex flex-col md:flex-row bg-white rounded-lg shadow-md overflow-hidden">
          <div className="md:w-1/2 p-6 md:p-10 bg-primary text-white">
            <h3 className="font-bold text-2xl mb-6">Get in Touch</h3>
            <div className="mb-6">
              <h4 className="font-semibold text-lg mb-2">Our Office</h4>
              <p className="mb-1 flex items-start">
                <MapPin className="mr-3 h-5 w-5 flex-shrink-0 mt-0.5" />
                <span>
                  123 Medical Plaza, Suite 400<br />
                  Boston, MA 02115<br />
                  United States
                </span>
              </p>
            </div>
            <div className="mb-6">
              <h4 className="font-semibold text-lg mb-2">Contact Information</h4>
              <p className="flex items-center mb-2">
                <Phone className="mr-3 h-5 w-5 flex-shrink-0" />
                <span>+1 (800) 555-7890</span>
              </p>
              <p className="flex items-center mb-2">
                <Mail className="mr-3 h-5 w-5 flex-shrink-0" />
                <span>info@qrxconsulting.com</span>
              </p>
              <p className="flex items-center">
                <Clock className="mr-3 h-5 w-5 flex-shrink-0" />
                <span>Monday - Friday: 9am - 5pm EST</span>
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-2">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-white hover:text-neutral-200 transition-colors">
                  <Linkedin size={24} />
                  <span className="sr-only">LinkedIn</span>
                </a>
                <a href="#" className="text-white hover:text-neutral-200 transition-colors">
                  <Twitter size={24} />
                  <span className="sr-only">Twitter</span>
                </a>
                <a href="#" className="text-white hover:text-neutral-200 transition-colors">
                  <Facebook size={24} />
                  <span className="sr-only">Facebook</span>
                </a>
              </div>
            </div>
          </div>
          <div className="md:w-1/2 p-6 md:p-10">
            <h3 className="font-bold text-2xl text-neutral-800 mb-6">Send us a Message</h3>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input placeholder="john.doe@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="service"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service of Interest</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="regulatory">Regulatory Compliance</SelectItem>
                          <SelectItem value="quality">Quality Assurance</SelectItem>
                          <SelectItem value="training">Training Programs</SelectItem>
                          <SelectItem value="other">Other Services</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please describe your needs or questions" 
                          className="min-h-[120px]" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full" size="lg">
                  Send Message
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
