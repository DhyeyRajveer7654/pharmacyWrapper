import SectionTitle from "@/components/ui/section-title";
import TeamCard from "@/components/ui/team-card";

const teamMembers = [
  {
    name: "Dr. Sarah Johnson",
    role: "Regulatory Affairs Director",
    description: "15+ years experience in pharmaceutical regulation",
    imageUrl: "https://randomuser.me/api/portraits/women/76.jpg"
  },
  {
    name: "Dr. Michael Chen",
    role: "Quality Assurance Lead",
    description: "Former FDA quality systems inspector",
    imageUrl: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
    name: "Dr. Amanda Patel",
    role: "Compliance Specialist",
    description: "Expert in EU medical device regulations",
    imageUrl: "https://randomuser.me/api/portraits/women/45.jpg"
  },
  {
    name: "John Martinez",
    role: "Operations Director",
    description: "Specializes in process optimization",
    imageUrl: "https://randomuser.me/api/portraits/men/67.jpg"
  }
];

const stats = [
  { value: "50+", label: "Global Clients" },
  { value: "100%", label: "Compliance Rate" },
  { value: "20+", label: "Years Experience" },
  { value: "24/7", label: "Support" }
];

const AboutSection = () => {
  return (
    <section id="about" className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
            <SectionTitle title="About Us" />
            <p className="text-neutral-700 mb-4">
              QRx was founded by industry experts with over 20 years of experience in pharmaceutical and medical device industries. Our mission is to help organizations navigate complex regulatory requirements while maintaining the highest quality standards.
            </p>
            <p className="text-neutral-700 mb-4">
              We understand the unique challenges faced by medical and pharmaceutical companies in today's rapidly evolving landscape. Our team of specialists combines deep industry knowledge with practical experience to deliver solutions that ensure compliance and drive operational excellence.
            </p>
            <div className="flex flex-wrap">
              {stats.map((stat, index) => (
                <div key={index} className="w-1/2 mb-4">
                  <div className="font-bold text-3xl text-primary">{stat.value}</div>
                  <div className="text-neutral-700">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
              alt="Team of medical professionals" 
              className="rounded-lg shadow-lg w-full h-auto"
              width="600"
              height="400"
            />
          </div>
        </div>
        
        <div className="mt-16">
          <h3 className="font-bold text-2xl text-neutral-800 mb-6 text-center">Our Team</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, index) => (
              <TeamCard key={index} {...member} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
