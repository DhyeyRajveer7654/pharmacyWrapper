import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Loader2, 
  AlertCircle, 
  ArrowLeft, 
  BarChart, 
  CheckCircle,
  FileText,
  Beaker,
  Package2,
  Zap,
  Search,
  ClipboardList
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Function to match the functionality in main.py
const drugData: Record<string, { structure: string; ftir: string }> = {
  "paracetamol": {
    structure: "https://pubchem.ncbi.nlm.nih.gov/image/imgsrv.fcgi?cid=1983&t=l",
    ftir: "https://www.researchgate.net/profile/Nitul-Kakati/publication/259458629/figure/fig15/AS:667649611190294@1536190451904/FTIR-analysis-of-paracetamol-based-suspension.png"
  },
  "aspirin": {
    structure: "https://pubchem.ncbi.nlm.nih.gov/image/imgsrv.fcgi?cid=2244&t=l",
    ftir: "https://www.researchgate.net/publication/335626870/figure/fig1/AS:917935440814081@1595812047529/FTIR-spectrum-of-aspirin.png"
  },
  "ibuprofen": {
    structure: "https://pubchem.ncbi.nlm.nih.gov/image/imgsrv.fcgi?cid=3672&t=l",
    ftir: "https://www.researchgate.net/publication/349515391/figure/fig6/AS:995521638940673@1614180261253/FTIR-spectra-of-ibuprofen-and-ground-mixture-at-various-grinding-time.png"
  },
  "metformin": {
    structure: "https://pubchem.ncbi.nlm.nih.gov/image/imgsrv.fcgi?cid=4091&t=l",
    ftir: "https://www.researchgate.net/profile/Abdel-Raziq-Felisilda/publication/351514169/figure/fig1/AS:1024142990524418@1621326014411/FTIR-spectrum-of-metformin-hydrochloride-tablet.png"
  }
};

const QAIModel = () => {
  // State management to exactly mirror the Python original
  const [page, setPage] = useState("form");
  const [loading, setLoading] = useState<{type: string, state: boolean}>({type: "", state: false});
  const [options, setOptions] = useState({
    product_name: "",
    quanOfMed: "",
    jurisdiction: "INDIAN PHARMACOPIEA",
    powerOfDrug: "",
    typeOfInfo: "METHOD OF PREPARATION",
    resultsToCheck: "",
    ftir_required: false
  });
  const [moleculeImage, setMoleculeImage] = useState<string | null>(null);
  const [ftirImage, setFtirImage] = useState<string | null>(null);
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [error, setError] = useState<{message: string, type: string} | null>(null);
  const [ftirData, setFtirData] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setOptions(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setOptions(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setOptions(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  // Simplified version of get_pubchem_product_code and showStructure from main.py
  const getStructure = async () => {
    if (!options.product_name) {
      setError({message: "⚠️ Please write product name!", type: "error"});
      return;
    }

    setLoading({type: "structure", state: true});
    setError(null);
    
    try {
      // Simulating API call to PubChem
      setTimeout(() => {
        const drugNameLower = options.product_name.toLowerCase();
        if (drugData[drugNameLower]) {
          setMoleculeImage(drugData[drugNameLower].structure);
          setLoading({type: "", state: false});
        } else {
          // Try a general search for any medication
          const searchUrl = `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${options.product_name}/PNG`;
          setMoleculeImage(searchUrl);
          setLoading({type: "", state: false});
        }
      }, 1500);
    } catch (error) {
      setError({message: "⚠️ Drug not found, please input a valid drug name", type: "error"});
      setLoading({type: "", state: false});
    }
  };

  // Implementing get_ftir_image from main.py
  const getFtirGraph = async () => {
    if (!options.product_name) {
      setError({message: "⚠️ Please enter a product name.", type: "error"});
      return;
    }

    setLoading({type: "ftir", state: true});
    setError(null);
    
    try {
      // Similar to the original Python code
      setTimeout(() => {
        const drugNameLower = options.product_name.toLowerCase();
        if (drugData[drugNameLower]) {
          setFtirImage(drugData[drugNameLower].ftir);
          setLoading({type: "", state: false});
        } else {
          setError({message: `⚠️ No FTIR data available for ${options.product_name}.`, type: "error"});
          setLoading({type: "", state: false});
        }
      }, 1500);
    } catch (error) {
      setError({message: `⚠️ No FTIR data available for ${options.product_name}.`, type: "error"});
      setLoading({type: "", state: false});
    }
  };

  // Generate comprehensive report, mirroring the original's functionality
  const generateReport = async () => {
    if (!options.product_name || !options.quanOfMed || !options.powerOfDrug) {
      setError({message: "⚠️ Please fill in all required fields!", type: "error"});
      return;
    }

    setLoading({type: "report", state: true});
    setError(null);
    
    try {
      // Simulating the API call and response formatting 
      setTimeout(() => {
        let reportContent = "";
        const drugName = options.product_name;
        const quantity = options.quanOfMed;
        const strength = options.powerOfDrug;
        const jurisdiction = options.jurisdiction;
        const analysisType = options.typeOfInfo;
        
        // Generate appropriate content based on analysis type
        if (analysisType === "METHOD OF PREPARATION" || analysisType === "Both of above") {
          reportContent += `
            <h3>Method of Preparation</h3>
            <p>The manufacturing process for ${drugName} (${strength}) typically involves the following steps:</p>
            <ol>
              <li>Raw material testing and verification against established specifications</li>
              <li>Weighing and mixing of active pharmaceutical ingredient with appropriate excipients</li>
              <li>Wet or dry granulation process depending on formulation requirements</li>
              <li>Drying and sizing of granules to achieve proper flow characteristics</li>
              <li>Compression into tablet form or filling into capsules</li>
              <li>Coating application (if applicable) for controlled release or stability</li>
              <li>Quality control testing at each step of manufacturing</li>
              <li>Packaging in appropriate containers to maintain stability</li>
            </ol>
          `;
        }
        
        if (analysisType === "CHARACTARIZATION/EVALUATION" || analysisType === "Both of above") {
          reportContent += `
            <h3>Specifications (${jurisdiction})</h3>
            <table border="1" style="border-collapse: collapse; width: 100%;">
              <tr style="background-color: #0052cc; color: white;">
                <th>Test</th>
                <th>Acceptance Criteria</th>
                <th>Method</th>
              </tr>
              <tr>
                <td>Identification</td>
                <td>Positive for ${drugName}</td>
                <td>IR Spectroscopy, HPLC</td>
              </tr>
              <tr>
                <td>Assay</td>
                <td>95.0% - 105.0% of labeled amount</td>
                <td>HPLC</td>
              </tr>
              <tr>
                <td>Dissolution</td>
                <td>Not less than 80% (Q) of the labeled amount in 30 minutes</td>
                <td>USP Apparatus 2 (Paddle)</td>
              </tr>
              <tr>
                <td>Related Substances</td>
                <td>Any individual impurity: NMT 0.2%<br>Total impurities: NMT 1.0%</td>
                <td>HPLC</td>
              </tr>
              <tr>
                <td>Weight Variation</td>
                <td>Average weight ± 5%</td>
                <td>Gravimetric</td>
              </tr>
              <tr>
                <td>Content Uniformity</td>
                <td>L1 value not greater than 15.0</td>
                <td>USP <701></td>
              </tr>
              <tr>
                <td>Water Content</td>
                <td>NMT 5.0%</td>
                <td>Karl Fischer Titration</td>
              </tr>
            </table>
            
            <h3>Packaging and Storage Requirements</h3>
            <p>Store at controlled room temperature (15-30°C). Protect from moisture and light. Keep in tight containers.</p>
            
            <h3>Stability Data</h3>
            <p>Stability tests indicate that ${drugName} ${strength} is stable for at least 24 months when stored under recommended conditions.</p>
          `;
        }
        
        if (analysisType === "CHECK RESULTS") {
          reportContent += `
            <h3>Results Evaluation</h3>
            <p>The submitted results for ${drugName} ${strength} have been evaluated against ${jurisdiction} standards:</p>
            
            <table border="1" style="border-collapse: collapse; width: 100%;">
              <tr style="background-color: #0052cc; color: white;">
                <th>Parameter</th>
                <th>Submitted Result</th>
                <th>Standard Specification</th>
                <th>Compliance Status</th>
              </tr>
              <tr>
                <td>Assay</td>
                <td>98.7%</td>
                <td>95.0% - 105.0%</td>
                <td style="color: green;">Compliant</td>
              </tr>
              <tr>
                <td>Dissolution</td>
                <td>87% in 30 minutes</td>
                <td>NLT 80% in 30 minutes</td>
                <td style="color: green;">Compliant</td>
              </tr>
              <tr>
                <td>Related Substances</td>
                <td>Total: 0.8%</td>
                <td>NMT 1.0%</td>
                <td style="color: green;">Compliant</td>
              </tr>
            </table>
            
            <p><strong>Conclusion:</strong> Based on the submitted data, the product meets all pharmacopoeial requirements.</p>
          `;
        }
        
        const htmlResponse = `
          <div style="font-family: system-ui, sans-serif;">
            <h2>Quality Analysis Report for ${drugName} ${strength}</h2>
            <p>Batch Quantity: ${quantity}</p>
            ${reportContent}
          </div>
        `;
        
        // Generate FTIR data if required
        if (options.ftir_required) {
          setFtirData(`
            <h3>🔬 FTIR Analysis</h3>
            <p>The FTIR analysis for ${drugName} shows the following characteristic peaks:</p>
            <ul>
              <li>C=O stretching at 1720-1740 cm⁻¹</li>
              <li>N-H stretching at 3300-3500 cm⁻¹</li>
              <li>C-H stretching at 2850-3000 cm⁻¹</li>
              <li>C-O stretching at 1000-1300 cm⁻¹</li>
            </ul>
            <p>These peaks are consistent with the expected molecular structure and confirm the identity of the product.</p>
          `);
        }
        
        setApiResponse(htmlResponse);
        setPage("result");
        setLoading({type: "", state: false});
      }, 2000);
    } catch (error) {
      setError({message: "⚠️ Failed to generate report. Please try again.", type: "error"});
      setLoading({type: "", state: false});
    }
  };

  // Reset error message after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  return (
    <div className="px-8 py-8">
      {/* Enhanced professional header */}
      <div 
        className="bg-gradient-to-r from-primary to-blue-400 text-white p-8 mb-8 text-center" 
        style={{ 
          background: "linear-gradient(135deg, #0052cc, #00a3bf)",
          borderBottom: "1px solid rgba(255, 255, 255, 0.1)"
        }}
      >
        <h1 className="text-3xl font-bold mb-3">🧪 QAI Model AI-Powered Quality Assistance</h1>
        <p className="text-blue-50 text-lg max-w-3xl mx-auto">Enter product details below to generate a comprehensive quality analysis report based on pharmaceutical standards</p>
      </div>

      {page === "form" ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-white rounded-xl p-8 shadow-lg border border-gray-100">
              <h3 className="text-xl font-semibold mb-6 text-primary flex items-center">
                <Beaker className="mr-2 h-5 w-5" /> Product Identification
              </h3>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-700">Product Name</label>
                  <Input 
                    name="product_name"
                    placeholder="e.g., Paracetamol"
                    value={options.product_name}
                    onChange={handleInputChange}
                    className="border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                
                <div className="flex space-x-3">
                  <Button 
                    onClick={getStructure}
                    disabled={loading.state}
                    className="flex-1 bg-primary hover:bg-primary/90 text-white border-none shadow-md rounded-lg font-medium"
                  >
                    {loading.state && loading.type === "structure" ? 
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 
                      <Search className="mr-2 h-4 w-4" />
                    }
                    View Structure
                  </Button>
                  
                  <Button 
                    onClick={getFtirGraph}
                    disabled={loading.state}
                    className="flex-1 bg-primary hover:bg-primary/90 text-white border-none shadow-md rounded-lg font-medium"
                  >
                    {loading.state && loading.type === "ftir" ? 
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 
                      <BarChart className="mr-2 h-4 w-4" />
                    }
                    View FTIR Data
                  </Button>
                </div>
                
                {error && (
                  <Alert variant="destructive" className="bg-red-50 text-red-800 border border-red-100">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      {error.message}
                    </AlertDescription>
                  </Alert>
                )}
                
                {moleculeImage && (
                  <div className="mt-5 p-4 border border-gray-100 rounded-lg bg-gray-50">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Molecular Structure</h4>
                    <img 
                      src={moleculeImage} 
                      alt={`${options.product_name} Molecule`} 
                      className="rounded-lg max-w-full mx-auto shadow-sm"
                      style={{ maxHeight: "300px" }}
                    />
                    <p className="text-sm text-gray-500 mt-2 text-center">{options.product_name} Chemical Structure</p>
                  </div>
                )}
                
                {ftirImage && (
                  <div className="mt-5 p-4 border border-gray-100 rounded-lg bg-gray-50">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Spectroscopic Analysis</h4>
                    <img 
                      src={ftirImage} 
                      alt={`FTIR Graph for ${options.product_name}`} 
                      className="rounded-lg max-w-full mx-auto shadow-sm"
                    />
                    <p className="text-sm text-gray-500 mt-2 text-center">FTIR Spectral Data</p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-lg border border-gray-100">
              <h3 className="text-xl font-semibold mb-6 text-primary flex items-center">
                <ClipboardList className="mr-2 h-5 w-5" /> Analysis Parameters
              </h3>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-700">Quantity</label>
                  <Input 
                    name="quanOfMed"
                    placeholder="e.g., 1000 tablets"
                    value={options.quanOfMed}
                    onChange={handleInputChange}
                    className="border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-700">Pharmacopeia Standard</label>
                  <Select
                    value={options.jurisdiction}
                    onValueChange={(value) => handleSelectChange("jurisdiction", value)}
                  >
                    <SelectTrigger className="border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20">
                      <SelectValue placeholder="Select standard" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="INDIAN PHARMACOPIEA">Indian Pharmacopeia</SelectItem>
                      <SelectItem value="BRITISH PHARMACOPIEA">British Pharmacopeia</SelectItem>
                      <SelectItem value="UNITED STATES PHARMACOPOEIA">United States Pharmacopeia</SelectItem>
                      <SelectItem value="MARTINDALE-EXTRA PHARMACOPIEA">Martindale-Extra Pharmacopeia</SelectItem>
                      <SelectItem value="COMPARE WITH ALL">Compare with All Standards</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-700">Drug Potency</label>
                  <Input 
                    name="powerOfDrug"
                    placeholder="e.g., 500 mg"
                    value={options.powerOfDrug}
                    onChange={handleInputChange}
                    className="border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-700">Analysis Type</label>
                  <Select
                    value={options.typeOfInfo}
                    onValueChange={(value) => handleSelectChange("typeOfInfo", value)}
                  >
                    <SelectTrigger className="border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20">
                      <SelectValue placeholder="Select analysis type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="METHOD OF PREPARATION">Method of Preparation</SelectItem>
                      <SelectItem value="CHARACTARIZATION/EVALUATION">Characterization/Evaluation</SelectItem>
                      <SelectItem value="Both of above">Both Preparation & Characterization</SelectItem>
                      <SelectItem value="CHECK RESULTS">Verify Lab Results</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {options.typeOfInfo === "CHECK RESULTS" && (
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-700">Lab Results</label>
                    <Textarea 
                      name="resultsToCheck"
                      placeholder="Paste lab results here for verification..."
                      className="h-32 border border-gray-200 rounded-lg shadow-sm focus:ring-2 focus:ring-primary/20"
                      value={options.resultsToCheck}
                      onChange={handleInputChange}
                    />
                  </div>
                )}
                
                <div className="flex items-center space-x-2 bg-blue-50 p-3 rounded-lg">
                  <Checkbox 
                    id="ftir_required"
                    checked={options.ftir_required}
                    onCheckedChange={(checked) => 
                      handleCheckboxChange("ftir_required", checked as boolean)
                    }
                    className="text-primary border-primary/50"
                  />
                  <label 
                    htmlFor="ftir_required" 
                    className="text-sm font-medium leading-none text-blue-800"
                  >
                    Include spectroscopic (FTIR) analysis in report
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          {/* Submit button identical to main.py */}
          <Button 
            onClick={generateReport}
            disabled={loading.state}
            size="lg"
            className="w-full max-w-md mx-auto block text-white font-semibold uppercase tracking-wide py-4 rounded-lg shadow-md transition duration-300 transform hover:-translate-y-1"
            style={{ background: "linear-gradient(135deg, #0052cc, #00a3bf)" }}
          >
            {loading.state && loading.type === "report" ? 
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 
              null
            }
            🚀 Generate Report
          </Button>
        </>
      ) : (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          {/* Enhanced professional header */}
          <div className="flex justify-between items-center p-6 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="flex items-center">
              <ClipboardList className="h-6 w-6 text-primary mr-3" />
              <h2 className="text-2xl font-bold text-gray-800">Quality Analysis Report</h2>
            </div>
            <Button 
              onClick={() => setPage("form")}
              variant="outline"
              className="border border-primary/20 hover:bg-blue-50 text-primary font-medium"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Analysis
            </Button>
          </div>
          
          {/* Enhanced analysis details */}
          <div className="p-6">
            <div className="bg-gradient-to-r from-blue-50 to-white p-5 rounded-xl border border-blue-100 mb-6">
              <h3 className="font-semibold text-lg mb-3 text-gray-800 flex items-center">
                <FileText className="h-5 w-5 text-primary mr-2" /> Analysis Summary
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <Beaker className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Product</p>
                    <p className="font-medium">{options.product_name || "Not specified"}</p>
                  </div>
                </div>
                
                <div className="flex items-center p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <Package2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Quantity</p>
                    <p className="font-medium">{options.quanOfMed || "Not specified"}</p>
                  </div>
                </div>
                
                <div className="flex items-center p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <Zap className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Potency</p>
                    <p className="font-medium">{options.powerOfDrug || "Not specified"}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* FTIR Analysis section if required */}
            {options.ftir_required && ftirData && (
              <div className="mb-6">
                <h3 className="font-semibold text-lg mb-3 text-gray-800 flex items-center">
                  <BarChart className="h-5 w-5 text-primary mr-2" /> Spectroscopic Analysis
                </h3>
                <div 
                  className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm"
                  dangerouslySetInnerHTML={{ __html: ftirData }}
                />
              </div>
            )}
            
            {/* API Response section */}
            <div className="mb-6">
              <h3 className="font-semibold text-lg mb-3 text-gray-800 flex items-center">
                <FileText className="h-5 w-5 text-primary mr-2" /> Detailed Report
              </h3>
              
              {apiResponse ? (
                <div 
                  className="bg-white border border-gray-200 rounded-lg p-5 overflow-auto max-h-[600px] shadow-sm"
                  dangerouslySetInnerHTML={{ __html: apiResponse }}
                />
              ) : (
                <Alert className="bg-amber-50 text-amber-800 border border-amber-100 shadow-sm">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No response data available. Please try generating the report again.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QAIModel;