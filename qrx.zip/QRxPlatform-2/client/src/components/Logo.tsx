const Logo = () => {
  return (
    <div className="text-primary font-bold text-2xl md:text-3xl">
      <span>QR</span><span className="text-primary">x</span>
    </div>
  );
};

export default Logo;
