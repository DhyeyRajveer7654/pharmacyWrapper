import { useState } from "react";
import { Link, useLocation } from "wouter";
import Logo from "./Logo";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const navItems = [
  { name: "Home", path: "/" },
  { name: "Services", path: "/#services" },
  { name: "About Us", path: "/#about" },
  { name: "Contact Us", path: "/#contact" },
];

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const handleNavClick = (path: string) => {
    setMobileMenuOpen(false);
    
    // Handle anchor navigation when on home page
    if (location === "/" && path.startsWith("/#")) {
      const id = path.substring(2);
      const element = document.getElementById(id);
      if (element) {
        window.scrollTo({
          top: element.offsetTop - 80,
          behavior: "smooth",
        });
      }
    }
  };

  return (
    <nav className="fixed top-0 w-full bg-white shadow-md z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <Logo />
          </Link>
        </div>
        
        {/* Mobile menu button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex space-x-6 items-center">
          {navItems.map((item) => (
            <span 
              key={item.name}
              className="font-medium text-neutral-700 hover:text-primary transition-colors cursor-pointer"
              onClick={() => {
                handleNavClick(item.path);
                window.location.href = item.path;
              }}
            >
              {item.name}
            </span>
          ))}
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-neutral-200">
          <div className="container mx-auto px-4 py-2 flex flex-col space-y-3">
            {navItems.map((item) => (
              <span 
                key={item.name}
                className="text-neutral-700 hover:text-primary py-2 transition-colors cursor-pointer"
                onClick={() => {
                  handleNavClick(item.path);
                  window.location.href = item.path;
                }}
              >
                {item.name}
              </span>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
