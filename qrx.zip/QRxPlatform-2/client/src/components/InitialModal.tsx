import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight } from "lucide-react";

interface InitialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const InitialModal = ({ isOpen, onClose }: InitialModalProps) => {
  const [isVisible, setIsVisible] = useState(isOpen);

  useEffect(() => {
    setIsVisible(isOpen);
  }, [isOpen]);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  if (!isVisible && !isOpen) return null;

  return (
    <div 
      className={`fixed inset-0 flex items-center justify-center z-50 transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
    >
      <Card className="absolute bg-white rounded-lg shadow-xl p-6 w-11/12 max-w-md transform -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2">
        <CardContent className="p-0">
          <div className="text-center mb-6">
            <h2 className="font-bold text-2xl text-primary mb-2">Choose an Option</h2>
            <p className="text-neutral-700 text-sm mb-4">Select a service area to explore</p>
            
            <div className="flex flex-col space-y-4">
              <div 
                className="flex items-center justify-between bg-white border-2 border-primary text-primary font-medium py-3 px-4 rounded-lg hover:bg-primary hover:text-white transition-all duration-300 hover:translate-y-[-2px] hover:shadow-md cursor-pointer"
                onClick={() => window.location.href = "/regulatory-compliance"}
              >
                <span className="text-lg">OPTION 1: REGULATORY COMPLIANCE</span>
                <ChevronRight className="h-5 w-5" />
              </div>
              
              <div 
                className="flex items-center justify-between bg-white border-2 border-primary text-primary font-medium py-3 px-4 rounded-lg hover:bg-primary hover:text-white transition-all duration-300 hover:translate-y-[-2px] hover:shadow-md cursor-pointer"
                onClick={() => window.location.href = "/quality-assurance"}
              >
                <span className="text-lg">OPTION 2: QUALITY ASSURANCE</span>
                <ChevronRight className="h-5 w-5" />
              </div>
            </div>
          </div>
          
          <div className="text-center mt-4">
            <Button
              variant="ghost"
              onClick={handleClose}
              className="text-sm text-neutral-500 hover:text-neutral-700 transition-colors"
            >
              Continue to main site
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InitialModal;
