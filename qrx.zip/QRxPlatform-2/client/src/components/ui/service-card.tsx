import { Link } from "wouter";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { LucideIcon } from "lucide-react";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  features: string[];
  linkTo: string;
  bgColor: string;
  buttonColor?: string;
}

const ServiceCard = ({
  title,
  description,
  icon: Icon,
  features,
  linkTo,
  bgColor,
  buttonColor = "primary"
}: ServiceCardProps) => {
  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg">
      <div className={`h-48 ${bgColor} flex items-center justify-center`}>
        <Icon className="text-white" size={48} />
      </div>
      <CardContent className="p-6">
        <h3 className="font-bold text-xl text-neutral-800 mb-3">{title}</h3>
        <p className="text-neutral-700 mb-4">
          {description}
        </p>
        <ul className="mb-6 text-neutral-700">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start mb-2 last:mb-0">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-secondary mr-2 mt-1 flex-shrink-0"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Link href={linkTo}>
          <Button variant={buttonColor as "default" | "secondary"} className="w-full justify-center">
            Learn More
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
};

export default ServiceCard;
