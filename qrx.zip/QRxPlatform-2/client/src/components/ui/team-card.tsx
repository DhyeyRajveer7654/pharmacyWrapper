import { Avatar, AvatarFallback, AvatarImage } from "./avatar";

interface TeamMemberProps {
  name: string;
  role: string;
  description: string;
  imageUrl: string;
}

const TeamCard = ({ name, role, description, imageUrl }: TeamMemberProps) => {
  // Get initials from name for fallback
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <div className="bg-neutral-100 rounded-lg p-6 text-center">
      <Avatar className="w-24 h-24 mx-auto mb-4">
        <AvatarImage src={imageUrl} alt={name} />
        <AvatarFallback className="text-lg">{initials}</AvatarFallback>
      </Avatar>
      <h4 className="font-semibold text-lg text-neutral-800 mb-1">{name}</h4>
      <p className="text-primary text-sm font-medium mb-2">{role}</p>
      <p className="text-neutral-700 text-sm">
        {description}
      </p>
    </div>
  );
};

export default TeamCard;
