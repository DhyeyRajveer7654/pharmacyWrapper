import { Link } from "wouter";
import Logo from "../Logo";
import { Button } from "./button";
import { Input } from "./input";
import { Facebook, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-8 md:mb-0">
            <div className="text-white font-bold text-2xl mb-4">
              <span>QR</span><span className="text-white">x</span>
            </div>
            <p className="text-neutral-300 max-w-xs">
              Professional solutions for medical and pharmaceutical industries, ensuring compliance and quality.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/"}>Home</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/#services"}>Services</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/#about"}>About Us</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/#contact"}>Contact Us</span></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Services</h4>
              <ul className="space-y-2">
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/regulatory-compliance"}>Regulatory Compliance</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/quality-assurance"}>Quality Assurance</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/#services"}>Consulting Services</span></li>
                <li><span className="text-neutral-300 hover:text-white transition-colors cursor-pointer" onClick={() => window.location.href = "/#services"}>Training Programs</span></li>
              </ul>
            </div>
            <div className="col-span-2 md:col-span-1">
              <h4 className="font-semibold text-lg mb-4">Newsletter</h4>
              <p className="text-neutral-300 mb-3">Stay updated with our latest news and updates</p>
              <form className="flex" onSubmit={(e) => e.preventDefault()}>
                <Input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-1 rounded-r-none text-neutral-800 focus:outline-none"
                />
                <Button type="submit" className="bg-secondary hover:bg-secondary/90 text-white rounded-l-none">
                  <span className="sr-only">Submit</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-paper-plane"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                </Button>
              </form>
            </div>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} QRx Consulting. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-neutral-400 hover:text-white transition-colors">
              <Linkedin size={20} />
              <span className="sr-only">LinkedIn</span>
            </a>
            <a href="#" className="text-neutral-400 hover:text-white transition-colors">
              <Twitter size={20} />
              <span className="sr-only">Twitter</span>
            </a>
            <a href="#" className="text-neutral-400 hover:text-white transition-colors">
              <Facebook size={20} />
              <span className="sr-only">Facebook</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
