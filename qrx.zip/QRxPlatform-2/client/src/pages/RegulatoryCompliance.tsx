import { Link } from "wouter";
import SectionTitle from "@/components/ui/section-title";
import { Button } from "@/components/ui/button";
import Footer from "@/components/ui/footer";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, CheckCircle, FileText, ShieldCheck, Users } from "lucide-react";

const RegulatoryCompliance = () => {
  return (
    <div className="pt-20">
      <div className="bg-primary text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <Link href="/">
            <a className="inline-flex items-center text-white mb-8 hover:underline">
              <ArrowLeft className="mr-2" size={20} />
              Back to Home
            </a>
          </Link>
          <h1 className="text-3xl md:text-5xl font-bold mb-6">Regulatory Compliance</h1>
          <p className="text-lg md:text-xl max-w-2xl">
            Navigate complex regulatory landscapes with our expert guidance. We ensure your processes and products 
            meet all necessary standards and requirements.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="h-12 w-12 bg-primary/10 text-primary flex items-center justify-center rounded-full mb-4">
                <FileText size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Documentation Expertise</h3>
              <p className="text-neutral-700">
                Our team provides comprehensive documentation preparation and review to ensure compliance with all regulatory requirements.
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="h-12 w-12 bg-primary/10 text-primary flex items-center justify-center rounded-full mb-4">
                <ShieldCheck size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Audit Preparation</h3>
              <p className="text-neutral-700">
                We'll help you prepare for regulatory audits with thorough assessments and preparation to ensure you pass with confidence.
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="h-12 w-12 bg-primary/10 text-primary flex items-center justify-center rounded-full mb-4">
                <Users size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Training Programs</h3>
              <p className="text-neutral-700">
                Comprehensive training for your team to ensure ongoing compliance with all relevant regulations.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-16">
          <SectionTitle title="Our Regulatory Expertise" centered />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-8">
            <div>
              <h3 className="text-xl font-bold mb-4">FDA Compliance</h3>
              <ul className="space-y-3">
                {[
                  "Pre-market approval guidance",
                  "Quality System Regulation compliance",
                  "Labeling requirements",
                  "Clinical trials oversight",
                  "Post-market surveillance"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary mr-2 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">International Regulations</h3>
              <ul className="space-y-3">
                {[
                  "EU MDR and IVDR compliance",
                  "Health Canada requirements",
                  "MHRA (UK) regulations",
                  "TGA (Australia) compliance",
                  "PMDA (Japan) requirements"
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-secondary mr-2 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-neutral-100 p-8 md:p-12 rounded-lg mb-16">
          <div className="text-center max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Ready to ensure complete regulatory compliance?</h3>
            <p className="mb-6 text-neutral-700">
              Our team of regulatory experts can help you navigate complex requirements and ensure your products meet all necessary standards.
            </p>
            <Link href="/#contact">
              <Button size="lg" className="text-base">
                Contact Our Regulatory Team
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default RegulatoryCompliance;
