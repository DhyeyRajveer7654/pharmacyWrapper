import Footer from "@/components/ui/footer";
import { ArrowLeft } from "lucide-react";
import QAIModel from "@/components/QAIModel";

const QualityAssurance = () => {
  return (
    <div className="pt-20">
      <div 
        className="bg-gradient-to-r from-primary to-blue-500 text-white py-16 md:py-24"
        style={{
          background: "linear-gradient(135deg, #0052cc, #0091ff)",
          boxShadow: "0 4px 30px rgba(0, 0, 0, 0.1)"
        }}
      >
        <div className="container mx-auto px-4">
          <div 
            className="inline-flex items-center text-white hover:text-blue-100 mb-8 cursor-pointer transition-colors"
            onClick={() => window.location.href = "/"}
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to Home
          </div>
          <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white drop-shadow-sm">AI-Powered Quality Assurance</h1>
          <p className="text-lg md:text-xl max-w-2xl text-blue-50">
            Our advanced AI-driven analysis helps pharmaceutical companies maintain the highest standards of quality and compliance.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 md:py-12 mt-[-2rem]">
        <div className="bg-white rounded-xl shadow-xl overflow-hidden">
          <QAIModel />
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default QualityAssurance;
